import { Routes, Route, Navigate } from "react-router-dom";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import Explanation from "./pages/explanation";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/explanation" element={<Explanation />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}