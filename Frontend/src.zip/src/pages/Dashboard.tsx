import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Activity, Settings, PhoneMissed, MessageSquareText } from "lucide-react";

type Stat = { label: string; value: string; hint?: string };

type FeedItem = {
  id: string;
  time: string;
  text: string;
  kind: "call" | "sms" | "reply";
};

export default function Dashboard() {
  const [tab, setTab] = useState<"overview" | "activity" | "settings">("overview");
  const [saving, setSaving] = useState(false);

  // Settings (later: load from backend)
  const [businessName, setBusinessName] = useState("Demo Pizza");
  const [notifyNumber, setNotifyNumber] = useState("+15559876543");
  const [cooldownMinutes, setCooldownMinutes] = useState(120);
  const [followupTemplate, setFollowupTemplate] = useState(
    "Hey! Sorry we missed your call to Demo Pizza. Reply with your name + order and we’ll get back ASAP. Reply STOP to opt out."
  );
  const [bookingLink, setBookingLink] = useState("https://your-booking-link.com");

  // Demo stats (later: computed from /admin/metrics)
  const stats: Stat[] = useMemo(
    () => [
      { label: "Missed calls captured", value: "12", hint: "Last 7 days" },
      { label: "Follow-up texts sent", value: "11", hint: "Last 7 days" },
      { label: "Customer replies", value: "4", hint: "Last 7 days" }
    ],
    []
  );

  // Demo activity (later: from /admin/events)
  const [feed, setFeed] = useState<FeedItem[]>([]);

  useEffect(() => {
    // seeded demo activity
    setFeed([
      {
        id: "1",
        time: "Just now",
        text: "Missed call from +1 (555) 000-1111",
        kind: "call"
      },
      { id: "2", time: "Just now", text: "Follow-up text sent", kind: "sms" },
      {
        id: "3",
        time: "1m ago",
        text: 'Customer replied: “Hi I want a large pepperoni”',
        kind: "reply"
      }
    ]);
  }, []);

  async function handleSave() {
    // Later: call PATCH /admin/businesses/:id
    setSaving(true);
    try {
      await new Promise((r) => setTimeout(r, 700));
      alert("Saved (demo). Next we’ll wire this to the backend PATCH route.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-50">
      <div className="mx-auto max-w-6xl px-6 py-10">
        {/* Top bar */}
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold tracking-tight text-zinc-900">
              Callsy Dashboard
            </div>
            <div className="mt-1 text-sm text-zinc-600">{businessName}</div>
          </div>

          <Link
            to="/"
            className="text-sm font-medium text-zinc-600 hover:text-zinc-900"
          >
            Landing
          </Link>
        </div>

        {/* Tabs */}
        <div className="mt-8 flex gap-2 rounded-2xl border border-zinc-200 bg-white p-2 shadow-sm">
          <TabButton active={tab === "overview"} onClick={() => setTab("overview")}>
            Overview
          </TabButton>
          <TabButton active={tab === "activity"} onClick={() => setTab("activity")}>
            Activity
          </TabButton>
          <TabButton active={tab === "settings"} onClick={() => setTab("settings")}>
            Settings
          </TabButton>
        </div>

        {/* Content */}
        {tab === "overview" && (
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {stats.map((s) => (
              <StatCard key={s.label} stat={s} />
            ))}
          </div>
        )}

        {tab === "activity" && (
          <div className="mt-6">
            <div className="text-sm font-medium text-zinc-900">Recent activity</div>
            <div className="mt-3 space-y-3">
              {feed.map((item) => (
                <FeedRow key={item.id} item={item} />
              ))}
            </div>
          </div>
        )}

        {tab === "settings" && (
          <div className="mt-6 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-zinc-900">Settings</div>
                <div className="mt-1 text-sm text-zinc-600">
                  Customize your follow-up and notifications.
                </div>
              </div>
              <button
                onClick={handleSave}
                disabled={saving}
                className="inline-flex items-center justify-center rounded-xl bg-zinc-900 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-zinc-800 disabled:opacity-50"
              >
                {saving ? "Saving…" : "Save"}
              </button>
            </div>

            <div className="mt-6 grid gap-5 md:grid-cols-2">
              <Field label="Business name">
                <Input value={businessName} onChange={setBusinessName} placeholder="Demo Pizza" />
              </Field>

              <Field label="Notify number">
                <Input value={notifyNumber} onChange={setNotifyNumber} placeholder="+1555..." />
              </Field>

              <Field label="Cooldown (minutes)">
                <Input
                  value={String(cooldownMinutes)}
                  onChange={(v) => setCooldownMinutes(Number(v))}
                  placeholder="120"
                />
              </Field>

              <Field label="Booking link (optional)">
                <Input value={bookingLink} onChange={setBookingLink} placeholder="https://..." />
              </Field>

              <div className="md:col-span-2">
                <Field label="Follow-up message">
                  <Textarea
                    value={followupTemplate}
                    onChange={setFollowupTemplate}
                    placeholder="Sorry we missed your call..."
                  />
                  <div className="mt-2 text-xs text-zinc-500">
                    Tip: you can later support placeholders like <code className="rounded bg-zinc-100 px-1">{"{{caller}}"}</code>{" "}
                    and <code className="rounded bg-zinc-100 px-1">{"{{link}}"}</code>.
                  </div>
                </Field>
              </div>
            </div>

            <div className="mt-6 rounded-xl border border-zinc-200 bg-zinc-50 p-4 text-sm text-zinc-700">
              <div className="font-medium text-zinc-900">Preview</div>
              <div className="mt-2 whitespace-pre-wrap">
                {followupTemplate}
                {bookingLink ? `\nBook here: ${bookingLink}` : ""}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/** UI bits */

function TabButton({
  active,
  onClick,
  children
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={[
        "flex-1 rounded-xl px-4 py-2 text-sm font-medium transition",
        active
          ? "bg-zinc-900 text-white"
          : "bg-transparent text-zinc-700 hover:bg-zinc-100"
      ].join(" ")}
    >
      {children}
    </button>
  );
}

function StatCard({ stat }: { stat: Stat }) {
  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      <div className="text-sm text-zinc-500">{stat.label}</div>
      <div className="mt-2 text-3xl font-semibold text-zinc-900">{stat.value}</div>
      {stat.hint ? <div className="mt-2 text-xs text-zinc-500">{stat.hint}</div> : null}
    </div>
  );
}

function FeedRow({ item }: { item: FeedItem }) {
  const icon =
    item.kind === "call" ? (
      <PhoneMissed size={18} />
    ) : item.kind === "sms" ? (
      <MessageSquareText size={18} />
    ) : (
      <Activity size={18} />
    );

  return (
    <div className="flex items-start gap-3 rounded-xl border border-zinc-200 bg-white px-4 py-3 shadow-sm">
      <div className="mt-0.5 inline-flex h-9 w-9 items-center justify-center rounded-xl bg-zinc-900 text-white">
        {icon}
      </div>
      <div className="flex-1">
        <div className="text-sm text-zinc-800">{item.text}</div>
        <div className="mt-1 text-xs text-zinc-500">{item.time}</div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-sm font-medium text-zinc-900">{label}</div>
      <div className="mt-2">{children}</div>
    </label>
  );
}

function Input({
  value,
  onChange,
  placeholder
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-zinc-900/10"
    />
  );
}

function Textarea({
  value,
  onChange,
  placeholder
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={5}
      className="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-zinc-900/10"
    />
  );
}