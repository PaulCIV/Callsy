import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { loginHandler, signupHandler } from "../controllers/auth.controller";

const router = Router();

router.post("/signup", asyncHandler(signupHandler));
router.post("/login", asyncHandler(loginHandler));

export default router;