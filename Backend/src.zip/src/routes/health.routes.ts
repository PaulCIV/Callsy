import { Router } from "express";
import {
  healthCheck,
  listBusinesses,
  createBusiness,
  updateBusiness,
  listLeads,
  listEvents
} from "../controllers/health.controller";

const router = Router();

/**
 * Health check (used by Railway / uptime monitors)
 */
router.get("/health", healthCheck);

/**
 * Admin routes (MVP, curl-only)
 */
router.get("/admin/businesses", listBusinesses);
router.post("/admin/businesses", createBusiness);
router.patch("/admin/businesses/:id", updateBusiness);

router.get("/admin/leads", listLeads);
router.get("/admin/events", listEvents);

export default router;