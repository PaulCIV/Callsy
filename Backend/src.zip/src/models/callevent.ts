import mongoose, { Schema } from "mongoose";

const CallEventSchema = new Schema(
  ({
    businessId: { type: Schema.Types.ObjectId, ref: "Business", required: true, index: true },

    // Twilio identifiers
    callSid: { type: String, required: true, index: true },

    from: { type: String, required: true, trim: true },
    to: { type: String, required: true, trim: true },

    // status callback fields
    callStatus: { type: String, required: true, trim: true },
    direction: { type: String, trim: true },

    // optional useful fields
    duration: { type: Number }, // seconds (sometimes string from Twilio; we’ll coerce later)
    answeredBy: { type: String, trim: true },

    raw: { type: Schema.Types.Mixed } // store entire webhook payload for debugging
  } as any),
  { timestamps: true }
);

CallEventSchema.index({ businessId: 1, callSid: 1 });

export const CallEvent =
  (mongoose.models.CallEvent as any) || mongoose.model("CallEvent", CallEventSchema);