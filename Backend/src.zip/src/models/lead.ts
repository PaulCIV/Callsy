import mongoose, { Schema } from "mongoose";

const LeadSchema = new Schema(
  ({
    businessId: { type: Schema.Types.ObjectId, ref: "Business", required: true, index: true },

    phone: { type: String, required: true, trim: true, index: true },

    // last time we sent a follow-up text (cooldown uses this)
    lastFollowupAt: { type: Date },

    // simple lead status for future (new/contacted/booked/etc.)
    status: { type: String, default: "new", trim: true }
  } as any),
  { timestamps: true }
);

// one lead per business+phone
LeadSchema.index({ businessId: 1, phone: 1 }, { unique: true });

export const Lead =
  (mongoose.models.Lead as any) || mongoose.model("Lead", LeadSchema);