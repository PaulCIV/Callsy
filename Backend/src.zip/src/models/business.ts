import mongoose, { Schema } from "mongoose";

const BusinessSchema = new Schema(
  ({
    name: { type: String, required: true, trim: true },

    forwardToNumber: { type: String, required: true, trim: true },
    twilioNumber: { type: String, required: true, trim: true },

    // ✅ IMPORTANT: just omit required:false entirely
    notifyToNumber: { type: String, trim: true },
    destinationNumber: { type: String, trim: true },

    followupTemplate: {
      type: String,
      required: true,
      trim: true,
      default:
        "Sorry we missed your call — how can we help? Reply here and we’ll get back to you ASAP. Reply STOP to opt out."
    },

    isActive: { type: Boolean, default: true },
    cooldownMinutes: { type: Number, default: 120 }
  } as any),
  { timestamps: true }
);

BusinessSchema.index({ twilioNumber: 1 }, { unique: true });

export const Business =
  (mongoose.models.Business as any) || mongoose.model("Business", BusinessSchema);