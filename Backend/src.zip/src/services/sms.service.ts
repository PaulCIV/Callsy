import { twilioClient } from "../config/twilio";
import { env } from "../config/env";

/**
 * Send an SMS (or dry-run log in development).
 * - `to`: recipient phone in E.164 (+1555...)
 * - `body`: message text
 * - `from`: optional override "from" number (usually the business's Twilio number)
 */
export async function sendSms(to: string, body: string, from?: string) {
  const fromNumber = from ?? env.TWILIO_DEFAULT_FROM;

  // Dry-run mode so you can build everything without buying/configuring a Twilio number yet
  if (env.NODE_ENV === "development" && process.env.SMS_DRY_RUN === "true") {
    console.log("📩 [DRY RUN SMS]", { from: fromNumber, to, body });
    return { sid: "DRY_RUN" };
  }

  // Real send
  return twilioClient.messages.create({
    from: fromNumber,
    to,
    body
  });
}