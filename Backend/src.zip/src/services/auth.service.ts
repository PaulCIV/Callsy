import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { env } from "../config/env";
import { User } from "../models/user";

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}


export async function signup(emailRaw: string, password: string) {
  const email = normalizeEmail(emailRaw);

  const existing = await User.findOne({ email });
  if (existing) {
    const err = new Error("Email already in use");
    // @ts-expect-error attach status
    err.status = 409;
    throw err;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await User.create({ email, passwordHash });

  const token = jwt.sign({ userId: user._id.toString() }, env.JWT_SECRET, {
    expiresIn: "7d"
  });

  return { user: { id: user._id.toString(), email: user.email }, token };
}

export async function login(emailRaw: string, password: string) {
  const email = normalizeEmail(emailRaw);

  const user = await User.findOne({ email });
  if (!user) {
    const err = new Error("Invalid email or password");
    // @ts-expect-error attach status
    err.status = 401;
    throw err;
  }

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    const err = new Error("Invalid email or password");
    // @ts-expect-error attach status
    err.status = 401;
    throw err;
  }

  const token = jwt.sign({ userId: user._id.toString() }, env.JWT_SECRET, {
    expiresIn: "7d"
  });

  return { user: { id: user._id.toString(), email: user.email }, token };
}