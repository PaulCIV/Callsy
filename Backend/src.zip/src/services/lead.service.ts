import { Lead } from "../models/lead";

export async function upsertLead(businessId: string, phone: string) {
  return Lead.findOneAndUpdate(
    { businessId, phone },
    { $setOnInsert: { status: "new" } },
    { new: true, upsert: true }
  );
}

export function isCooldownActive(lastFollowupAt: Date | undefined, cooldownMinutes: number): boolean {
  if (!lastFollowupAt) return false;
  const ms = Date.now() - new Date(lastFollowupAt).getTime();
  return ms < cooldownMinutes * 60 * 1000;
}

export async function markFollowupSent(leadId: string) {
  await Lead.updateOne(
    { _id: leadId },
    { $set: { lastFollowupAt: new Date(), status: "contacted" } }
  );
}