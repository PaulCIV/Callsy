export function buildFollowupMessage(template: string, callerPhone: string) {
    return String(template ?? "").split("{{caller}}").join(callerPhone);
  }