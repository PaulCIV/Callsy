import dotenv from "dotenv";
dotenv.config();

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  PORT: Number(process.env.PORT ?? 3001),

  MONGODB_URI: process.env.MONGODB_URI ?? "",

  FRONTEND_ORIGIN: process.env.FRONTEND_ORIGIN ?? "http://localhost:5173",

  JWT_SECRET: process.env.JWT_SECRET ?? "",
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN ?? "7d",

  
  TWILIO_ACCOUNT_SID: process.env.TWILIO_ACCOUNT_SID ?? "",
  TWILIO_AUTH_TOKEN: process.env.TWILIO_AUTH_TOKEN ?? "",
  TWILIO_PHONE_NUMBER: process.env.TWILIO_PHONE_NUMBER ?? ""
};

function assertEnv() {
  const required = ["MONGODB_URI", "JWT_SECRET"] as const;
  for (const key of required) {
    if (!env[key] || env[key].trim() === "") {
      throw new Error(`Missing required env var: ${key}`);
    }
  }
}

assertEnv();