import { Request, Response } from "express";
import { signup, login } from "../services/auth.service";

function isValidEmail(email: string) {
  // simple, fine for MVP
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function signupHandler(req: Request, res: Response) {
  const { email, password } = req.body ?? {};

  if (typeof email !== "string" || !isValidEmail(email)) {
    return res.status(400).json({ error: "Valid email is required" });
  }
  if (typeof password !== "string" || password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  }

  const result = await signup(email, password);
  return res.status(201).json(result);
}

export async function loginHandler(req: Request, res: Response) {
  const { email, password } = req.body ?? {};

  if (typeof email !== "string" || typeof password !== "string") {
    return res.status(400).json({ error: "Email and password are required" });
  }

  const result = await login(email, password);
  return res.status(200).json(result);
}