import { Request, Response } from "express";
import { Business } from "../models/business";
import { CallEvent } from "../models/callevent";
import { upsertLead, isCooldownActive, markFollowupSent } from "../services/lead.service";
import { sendSms } from "../services/sms.service";
import { buildFollowupMessage } from "../services/call.service";
import { normalizePhone } from "../utils/normalizePhone";

function twiml(inner: string) {
  return `<Response>${inner}</Response>`;
}

export const voiceWebhook = async (req: Request, res: Response) => {
  // Twilio (or curl) sends these fields
  const from = normalizePhone(req.body?.From);
  const to = normalizePhone(req.body?.To);
  const callSid = String(req.body?.CallSid ?? "");

  // Find business by the Twilio number that was called (their assigned Twilio number)
  const business: any = await Business.findOne({ twilioNumber: to, isActive: true });
  if (!business) {
    res.type("text/xml");
    return res.send(twiml("<Hangup/>"));
  }

  // Log the inbound call (even in one-line mode, this helps you debug + show value)
  await CallEvent.create({
    businessId: business._id,
    callSid,
    from,
    to,
    callStatus: String(req.body?.CallStatus ?? "forwarded"),
    direction: String(req.body?.Direction ?? "inbound"),
    raw: req.body
  });

  // One-line mode: we never Dial back (avoids loops). We treat receipt as the trigger.
  const lead: any = await upsertLead(String(business._id), from);

  const cooldownMinutes = Number(business.cooldownMinutes ?? 120);
  const lastFollowupAt = lead?.lastFollowupAt as Date | undefined;

  if (!isCooldownActive(lastFollowupAt, cooldownMinutes)) {
    const template = String(
      business.followupTemplate ??
        "Sorry we may have missed your call — reply here and we’ll get back ASAP. Reply STOP to opt out."
    );

    const messageBody = String(buildFollowupMessage(template, from));

    // Send follow-up SMS from that business's assigned Twilio number (once real),
    // or fall back to TWILIO_DEFAULT_FROM.
    await sendSms(from, messageBody, business.twilioNumber);

    await markFollowupSent(String(lead._id));
  } else {
    console.log("⏳ Cooldown active — not texting again", {
      businessId: String(business._id),
      from,
      cooldownMinutes
    });
  }

  // Always hang up right away (we're not doing call bridging in one-line mode)
  res.type("text/xml");
  return res.send(twiml("<Hangup/>"));
};

export const smsInboundWebhook = async (req: Request, res: Response) => {
  const from = normalizePhone(req.body?.From); // customer
  const to = normalizePhone(req.body?.To);     // your Twilio number they texted
  const body = String(req.body?.Body ?? "").trim();

  const messageSid = String(req.body?.MessageSid ?? "");

  const business: any = await Business.findOne({ twilioNumber: to, isActive: true });
  if (!business) {
    return res.status(200).json({ ok: true }); // don't error to Twilio
  }

  // Log inbound SMS as an event too (reusing CallEvent as a generic event log for MVP)
  await CallEvent.create({
    businessId: business._id,
    callSid: messageSid || `SM_${Date.now()}`,
    from,
    to,
    callStatus: "sms-inbound",
    direction: "inbound",
    raw: req.body
  });

  // Forward the reply to the business owner/manager (notifyToNumber)
  const notifyTo = normalizePhone(business.notifyToNumber ?? "");
  if (notifyTo) {
    const forwardMsg =
      `📩 New reply for ${business.name}\n` +
      `From: ${from}\n` +
      `Message: ${body}`;

    await sendSms(notifyTo, forwardMsg, business.twilioNumber);
  } else {
    console.log("⚠️ notifyToNumber not set — cannot forward inbound SMS", {
      businessId: String(business._id),
      businessName: business.name
    });
  }

  // Reply 200 OK so Twilio doesn't retry
  return res.status(200).json({ ok: true });
};

export const callStatusWebhook = async (_req: Request, res: Response) => {
  // Not used in one-line mode, but keeping route alive.
  res.status(200).json({ ok: true });
};