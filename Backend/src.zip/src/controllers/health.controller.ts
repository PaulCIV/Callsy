import { Request, Response } from "express";
import { Business } from "../models/business";
import { Lead } from "../models/lead";
import { CallEvent } from "../models/callevent";

/**
 * GET /health
 * Simple uptime / deploy health check
 */
export const healthCheck = (_req: Request, res: Response) => {
  res.status(200).json({
    status: "ok",
    timestamp: new Date().toISOString()
  });
};

/**
 * GET /admin/businesses
 * List all businesses (MVP admin)
 */
export const listBusinesses = async (_req: Request, res: Response) => {
  const businesses = await Business.find().sort({ createdAt: -1 }).lean();
  res.status(200).json({ ok: true, businesses });
};

/**
 * POST /admin/businesses
 * Create a new business
 */
export const createBusiness = async (req: Request, res: Response) => {
  const {
    name,
    forwardToNumber,
    twilioNumber,
    notifyToNumber,
    destinationNumber,
    followupTemplate,
    cooldownMinutes,
    callHandlingMode
  } = req.body ?? {};

  if (!name || !twilioNumber || !forwardToNumber) {
    return res.status(400).json({
      ok: false,
      error: "name, twilioNumber, and forwardToNumber are required"
    });
  }

  const business = await Business.create({
    name: String(name),
    forwardToNumber: String(forwardToNumber),
    twilioNumber: String(twilioNumber),
    notifyToNumber: notifyToNumber ? String(notifyToNumber) : undefined,
    destinationNumber: destinationNumber ? String(destinationNumber) : undefined,
    followupTemplate: followupTemplate ? String(followupTemplate) : undefined,
    cooldownMinutes: cooldownMinutes != null ? Number(cooldownMinutes) : undefined,
    callHandlingMode: callHandlingMode ? String(callHandlingMode) : undefined
  });

  res.status(201).json({ ok: true, business });
};

/**
 * PATCH /admin/businesses/:id
 * Update allowed fields for a business
 */
export const updateBusiness = async (req: Request, res: Response) => {
  const { id } = req.params;

  const updates: any = {};
  const allowed = [
    "name",
    "forwardToNumber",
    "twilioNumber",
    "notifyToNumber",
    "destinationNumber",
    "followupTemplate",
    "cooldownMinutes",
    "isActive",
    "callHandlingMode"
  ];

  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(req.body ?? {}, key)) {
      updates[key] = req.body[key];
    }
  }

  // Coerce types explicitly
  if (updates.name != null) updates.name = String(updates.name);
  if (updates.forwardToNumber != null) updates.forwardToNumber = String(updates.forwardToNumber);
  if (updates.twilioNumber != null) updates.twilioNumber = String(updates.twilioNumber);
  if (updates.notifyToNumber != null) updates.notifyToNumber = String(updates.notifyToNumber);
  if (updates.destinationNumber != null) updates.destinationNumber = String(updates.destinationNumber);
  if (updates.followupTemplate != null) updates.followupTemplate = String(updates.followupTemplate);
  if (updates.callHandlingMode != null) updates.callHandlingMode = String(updates.callHandlingMode);
  if (updates.cooldownMinutes != null) updates.cooldownMinutes = Number(updates.cooldownMinutes);

  const business = await Business.findByIdAndUpdate(id, updates, { new: true }).lean();

  if (!business) {
    return res.status(404).json({ ok: false, error: "Business not found" });
  }

  res.status(200).json({ ok: true, business });
};

/**
 * GET /admin/leads
 * View recent leads (debug / MVP visibility)
 */
export const listLeads = async (_req: Request, res: Response) => {
  const leads = await Lead.find().sort({ createdAt: -1 }).limit(50).lean();
  res.status(200).json({ ok: true, leads });
};

/**
 * GET /admin/events
 * View recent call + SMS events
 */
export const listEvents = async (_req: Request, res: Response) => {
  const events = await CallEvent.find().sort({ createdAt: -1 }).limit(50).lean();
  res.status(200).json({ ok: true, events });
};